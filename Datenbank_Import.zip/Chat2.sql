-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Erstellungszeit: 22. Jan 2021 um 17:28
-- Server-Version: 10.4.17-MariaDB
-- PHP-Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `DatenbankTut`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Chat2`
--

CREATE TABLE `Chat2` (
  `Message` varchar(999) NOT NULL,
  `Time` datetime NOT NULL DEFAULT current_timestamp(),
  `ID` int(11) NOT NULL,
  `Nutzer` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `Chat2`
--

INSERT INTO `Chat2` (`Message`, `Time`, `ID`, `Nutzer`) VALUES
('Hi', '2021-01-20 11:22:39', 95, 'test');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `Chat2`
--
ALTER TABLE `Chat2`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `Chat2`
--
ALTER TABLE `Chat2`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
